sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("workflowuimodule.controller.MyView",{onInit:function(){}})});
//# sourceMappingURL=MyView.controller.js.map